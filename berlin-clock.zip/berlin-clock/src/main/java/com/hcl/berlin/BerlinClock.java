package com.hcl.berlin;
import java.util.Arrays;
import java.util.Collections;

/**
 * Proramming Assisment of Berlin Clock.
 *
 * Creates a representation of a berlin clock from a String and provides
 * a way of printing this.
 *
 */
public class BerlinClock {

    private String formattedTime;
    private static final String CHANGE_LINE = System.getProperty("line.separator");

    /**
     * Create a new BerlinClock instance with a string representing time.
     *
     * @param time - The 24 hour time in the format of HH:MM:SS
     */
    public BerlinClock(String time) {

        if(time == null) throw new IllegalArgumentException("No time provided.");

        String[] times = time.split(":", 3);

        if(times.length != 3) throw new IllegalArgumentException("Invalid time provided.");

        int hours = Integer.parseInt(times[0]);
        int minutes = Integer.parseInt(times[1]);
        int seconds = Integer.parseInt(times[2]);

        if (hours < 0 || hours > 23) throw new IllegalArgumentException("Hours out of bounds.");
        if (minutes < 0 || minutes > 59) throw new IllegalArgumentException("Minutes out of bounds.");
        if (seconds < 0 || seconds > 59) throw new IllegalArgumentException("Seconds out of bounds.");

        this.formattedTime = processTime(hours, minutes, seconds);
    }

    /**
     * Convert individual hours, minutes and seconds into a BerlinTime object.
     *
     * @param hours - an int representing Hours
     * @param minutes - an int representing Minutes
     * @param seconds - an int representing Seconds
     *
     * @return BerlinTime object created using the parameters.
     */
    private String processTime(int hours, int minutes, int seconds) {

        String line1 = (seconds % 2 == 0) ? "Y" : "0";
        String line2 = rowOfLamps(hours / 5, 4, "R");
        String line3 = rowOfLamps(hours % 5, 4, "R");
        String line4 = rowOfLamps(minutes / 5, 11, "Y").replaceAll("YYY", "YYR");
        String line5 = rowOfLamps(minutes % 5, 4, "Y");

        return String.join(CHANGE_LINE, Arrays.asList(line1, line2, line3, line4, line5));

    }

    /**
     * Creates a string for each row of the berlin clock.
     * @param lampLights
     * @param lampLightsInRow
     * @param lampType
     * @returnn A string representing a single row of the clock.
     */
    private String rowOfLamps(int lampLights, int lampLightsInRow, String lampType) {

        int unLightLamp = lampLightsInRow - lampLights;
        String lampBlink = String.join("", Collections.nCopies(lampLights, lampType));
        String lampUnBlink = String.join("", Collections.nCopies(unLightLamp, "0"));
        

        return lampBlink + lampUnBlink;
    }

    /**
     * Print a representation of the berlin time.
     */
    public void printClock() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        return this.formattedTime;
    }


}
