package com.hcl.berlin;
public class BerlinClockDisplay{

    public static void main(String[] args) {

        BerlinClock clock = new BerlinClock(args[0]);

        System.out.println("====== Berlin Clock ======");
	   /* we have to give the argument to execute successfully.
		
        */	
        clock.printClock();
        System.out.println("==========================");
    }

}
